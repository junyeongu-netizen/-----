const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

ctx.fillStyle = 'skyblue';
ctx.fillRect(0, 0, canvas.width, canvas.height);

ctx.fillStyle = 'yellow';
ctx.font = '48px sans-serif';
ctx.fillText('게임 준비 완료!', 50, 100);
